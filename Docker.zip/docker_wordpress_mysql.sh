#!/bin/bash
docker stop $(docker ps -aq)
docker rm $(docker ps -aq)
docker rmi -f $(docker images -aq)

rm -rf /docker_data

mkdir -p /docker_data/db1
mkdir -p /docker_data/wordpress

docker pull mariadb
docker pull wordpress

docker run -itd --name db1 -p 3306:3306 \
-v /docker_data/db1:/var/lib/mysql \
-e MYSQL_ROOT_PASSWORD=container mariadb

docker run -it --name wordpress -p 80:80 \
--link db1:mysql \
-v /docker_data/wordpress:/var/www/html \
-e WORDPRESS_DB_NAME=wp \
-e WORDPRESS_DB_USER=root \
-e WORDPRESS_DB_PASSWORD=container \
-e ServerName=localhost \
-d wordpress

for i in $(seq 1 10)
do
  echo "Wait ${i} second..."
  sleep 1
done

echo
echo "Done! Please open http://localhost"
echo
#firefox http://localhost
