﻿2017.11.27 Version 0.0.1 Anderson Wang
  以 gwidx/pandas-python:latest 為基礎【Debian 8, python 3.5.2, pip 8.x】
  安裝 vi
  升級到 pip 9.0.1
  升級到 pandas 0.21.0
  安裝模組 beautifulsoup4, html5lib, lxml, numpy,
           python-dateutil, pytz, setuptools,
           six, webencodings
  如何使用：docker run -i -t python3_pandas bash
            docker run -i -t python3_pandas python /usr/src/app/currency.py 
  再次連線回 container：docker ps -a【查詢 container】
                        docker start -ai stoic_hoover0
  執行台灣銀行外匯爬蟲程式：python /usr/src/app/currency.py
