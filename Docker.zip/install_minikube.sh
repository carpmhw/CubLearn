#!/bin/bash
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg
https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF

yum install -y kubectl --nogpgcheck
yum install libvirt-daemon-kvm qemu-kvm -y
yum -y install bash-completion

source <(kubectl completion bash)
echo "source <(kubectl completion bash)" >> ~/.bashrc

yum -y install libvirt libvirt-daemon-kvm qemu-kvm virt-manager

wget https://storage.googleapis.com/minikube/releases/latest/docker-machine-driver-kvm2
#wget http://rh7lab.uuu.com.tw/download/Docker/docker-machine-driver-kvm2
install docker-machine-driver-kvm2 /usr/bin/docker-machine-driver-kvm2

#newgrp libvirt
#usermod -a -G libvirt $(whoami)

systemctl enable libvirtd && systemctl start libvirtd && systemctl status libvirtd

wget https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
#wget http://rh7lab.uuu.com.tw/download/Docker/minikube-linux-amd64
install minikube-linux-amd64 /usr/bin/minikube

minikube version
minikube start --cpus=2 --memory=2048 --vm-driver=kvm2

virsh list --all

kubectl version
kubectl cluster-info
kubectl get all

minikube status
minikube service list
#minikube dashboard

#kubectl run hello-minikube --image=gcr.io/google_containers/echoserver:1.4 --port=8080
#kubectl expose deployment hello-minikube --type=NodePort

kubectl get pods

minikube service list

#curl $(minikube service hello-minikube --url)

minikube ip
minikube docker-env

#minikube ssh
#
#$ docker ps
#$ docker images

kubectl get deployment
#kubectl delete deployment hello-minikube
kubectl get pods

minikube dashboard
